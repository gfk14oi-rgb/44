#include <iostream>
#include <cstdlib>
#include <string>
#include <fstream>

class GameEngineCore {
public:
    // Xử lý logic tính toán cấp thấp và tài nguyên phần cứng
    void runSimulation() {
        std::cout << "[C++] Dang khoi tao va kiem soat tai nguyen phan cung (CPU/RAM)...\n";
        
        // Mô phỏng việc sinh dữ liệu game từ phía C++
        std::ofstream outFile("game_data.txt");
        if (outFile.is_open()) {
            outFile << "EngineStatus=Active\nFrames=30\n";
            outFile.close();
        }
        std::cout << "[C++] Da xu ly xong du lieu nen cho he thong.\n";
    }
};

// Hàm giao tiếp phần cứng để kích hoạt tệp giao diện web
void openWebInterface() {
    std::string htmlFile = "index.html";
    std::cout << "[C++] Dang ra lenh cho phan cung he thong mo giao diện web...\n";
    
    #if defined(_WIN32) || defined(_WIN64)
        std::string command = "start " + htmlFile;
    #elif defined(__APPLE__)
        std::string command = "open " + htmlFile;
    #else
        std::string command = "xdg-open " + htmlFile;
    #endif

    int result = std::system(command.c_str());
    if (result == 0) {
        std::cout << "[C++] Mo giao dien web thanh cong.\n";
    } else {
        std::cerr << "[C++] Khong the tu động mo trinh duyet.\n";
    }
}

int main() {
    std::cout << "=== KHOI DONG HE THONG 2 FILE (C++ & WEB) ===\n\n";

    // 1. Chạy logic cốt lõi bằng C++
    GameEngineCore engine;
    engine.runSimulation();

    // 2. Kích hoạt giao diện Web thông qua C++
    openWebInterface();

    std::cout << "\n=== HOAN TAT TOAN BO QUY TRINH ==-\n";
    return 0;
}
